*WiiMC + YT*
*YT Support Version 1*
In order to use the WiiMC channel, you must
rename the folder in this directory to "wiimc".

Thanks!
